# Pale Court Charms
A hollow knight mod that adds charms from Pale Court.It was made to allow for more mod compatibility than the big Pale Court has.

Pale Court Charms has a Randomizer 4 integration,with options to enable charms and rando costs.Or you can not enable the connection and charms will have default costs and placements.

Is not expected to work with other mods that add charms,or change abillities.
However,it will work with transcendence and even has a few interactions(TranscendenceSynergies.md).Not chaos orb,at least yet.

See SpoilerCharmEffects.md to see what each charm does,it's cost and where to find it.

Hope you have fun!

Special thanks to Hollow Knight Modding Discord and the Pale Court team for helping me with code and allowing me to do this.

Also shoutouts to tranlsators: nonsenf for full german translation,wangha and my gf for additional rando translations. And yes,Pale Court Charms has translations that follow your game's language.